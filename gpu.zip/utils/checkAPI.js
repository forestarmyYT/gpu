const { log } = require("./utils"); // Adjust the path as necessary
const settings = require("../config/config");

// Simulated response data
const simulatedApiResponse = {
  endpoint: "https://example-api.com/api/v1",
  message: "If the API changes, please contact the ForestArmy group on Telegram for more info: https://t.me/forestarmy",
};

async function checkBaseUrl() {
  console.log("Checking API...");
  if (settings.ADVANCED_ANTI_DETECTION) {
    const result = await getBaseApi();
    if (result.endpoint) {
      log("No change in API!", "success");
      return result;
    }
  } else {
    return {
      endpoint: settings.BASE_URL,
      message:
        "If the API changes, please contact the ForestArmy group on Telegram for more info: https://t.me/forestarmy",
    };
  }
}

async function getBaseApi() {
  // Return the hardcoded response
  return simulatedApiResponse;
}

module.exports = { checkBaseUrl };