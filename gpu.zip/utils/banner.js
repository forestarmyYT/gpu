const banner = `Tool Shared By Airdrop Script FA But Was Made By Hunter (https://t.me/airdropscriptfa)`;
export default banner;
