const colors = require("colors");
function showBanner() {
  console.log(colors.cyan("Tool Is Perfectly Made By Airdrop Hunter and Shared By FORESTARMY (https://t.me/forestarmy)"));
}

module.exports = { showBanner };
